import pandas as pd
import numpy as np
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading


class UberAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Анализ данных Uber")
        self.root.geometry("900x700")

        self.df = None
        self.setup_ui()

    def setup_ui(self):
        # Основной фрейм
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Заголовок
        title_label = ttk.Label(main_frame, text="Анализ данных Uber",
                                font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))

        # Кнопки управления
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=1, column=0, columnspan=2, pady=(0, 10), sticky=(tk.W, tk.E))

        self.load_btn = ttk.Button(button_frame, text="Загрузить данные",
                                   command=self.load_data)
        self.load_btn.grid(row=0, column=0, padx=(0, 10))

        self.overview_btn = ttk.Button(button_frame, text="Обзор данных",
                                       command=self.show_overview, state="disabled")
        self.overview_btn.grid(row=0, column=1, padx=(0, 10))

        self.filter_btn = ttk.Button(button_frame, text="Фильтрация данных",
                                     command=self.show_filters, state="disabled")
        self.filter_btn.grid(row=0, column=2, padx=(0, 10))

        self.analyze_btn = ttk.Button(button_frame, text="Полный анализ",
                                      command=self.full_analysis, state="disabled")
        self.analyze_btn.grid(row=0, column=3, padx=(0, 10))

        # Новые кнопки для анализа пропущенных и уникальных значений
        self.missing_btn = ttk.Button(button_frame, text="Анализ пропущенных значений",
                                      command=self.analyze_missing_values, state="disabled")
        self.missing_btn.grid(row=0, column=4, padx=(0, 10))

        self.unique_btn = ttk.Button(button_frame, text="Анализ уникальных значений",
                                     command=self.analyze_unique_values, state="disabled")
        self.unique_btn.grid(row=0, column=5)

        # Область вывода результатов
        self.output_area = scrolledtext.ScrolledText(main_frame, width=100, height=35,
                                                     font=("Consolas", 9))
        self.output_area.grid(row=2, column=0, columnspan=2, pady=(10, 0),
                              sticky=(tk.W, tk.E, tk.N, tk.S))

        # Статус бар
        self.status_var = tk.StringVar(value="Готов к работе")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))

        # Настройка растягивания
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(2, weight=1)
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

    def load_data(self):
        def load_thread():
            try:
                self.update_status("Загрузка данных...")
                self.df = pd.read_csv("ncr_ride_bookings.csv")
                self.update_output("Файл загружен успешно!")
                self.update_output(f"Размер данных: {self.df.shape[0]} строк, {self.df.shape[1]} столбцов")

                # Активируем кнопки
                self.overview_btn.config(state="normal")
                self.filter_btn.config(state="normal")
                self.analyze_btn.config(state="normal")
                self.missing_btn.config(state="normal")
                self.unique_btn.config(state="normal")
                self.update_status("Данные загружены успешно")

            except FileNotFoundError:
                messagebox.showerror("Ошибка", "Файл 'ncr_ride_bookings.csv' не найден")
                self.update_status("Файл не найден")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Ошибка при загрузке: {e}")
                self.update_status("Ошибка загрузки")

        threading.Thread(target=load_thread, daemon=True).start()

    def analyze_missing_values(self):
        """Анализ пропущенных значений во всех столбцах"""
        if self.df is None:
            messagebox.showwarning("Предупреждение", "Сначала загрузите данные")
            return

        self.clear_output()
        self.update_output("=" * 70)
        self.update_output("АНАЛИЗ ПРОПУЩЕННЫХ ЗНАЧЕНИЙ")
        self.update_output("=" * 70)

        missing_data = self.df.isnull().sum()
        # ИСПРАВЛЕНИЕ: используем np.prod вместо np.product
        total_cells = np.prod(self.df.shape)
        total_missing = missing_data.sum()

        self.update_output(f"\nОбщее количество пропущенных значений: {total_missing}")
        self.update_output(f"Общее количество ячеек в данных: {total_cells}")
        self.update_output(f"Процент пропущенных значений: {(total_missing / total_cells) * 100:.2f}%")

        self.update_output("\nДетальный анализ по столбцам:")
        self.update_output("-" * 70)
        self.update_output(f"{'Столбец':<30} {'Пропущено':<12} {'Всего':<10} {'% пропусков':<15}")
        self.update_output("-" * 70)

        for col in self.df.columns:
            missing_count = missing_data[col]
            total_rows = len(self.df)
            missing_percent = (missing_count / total_rows) * 100
            self.update_output(f"{col:<30} {missing_count:<12} {total_rows:<10} {missing_percent:<15.2f}")

        # Анализ строк с пропущенными значениями
        rows_with_missing = self.df.isnull().any(axis=1).sum()
        self.update_output(f"\nКоличество строк с пропущенными значениями: {rows_with_missing}")
        self.update_output(f"Процент строк с пропущенными значениями: {(rows_with_missing / len(self.df)) * 100:.2f}%")

    def analyze_unique_values(self):
        """Анализ уникальных значений в категориальных столбцах"""
        if self.df is None:
            messagebox.showwarning("Предупреждение", "Сначала загрузите данные")
            return

        self.clear_output()
        self.update_output("=" * 70)
        self.update_output("АНАЛИЗ УНИКАЛЬНЫХ ЗНАЧЕНИЙ В КАТЕГОРИАЛЬНЫХ СТОЛБЦАХ")
        self.update_output("=" * 70)

        # Поиск категориальных столбцов
        categorical_columns = []
        for col in self.df.columns:
            if self.df[col].dtype == 'object' or self.df[col].nunique() < 50:
                categorical_columns.append(col)

        self.update_output(f"\nНайдено категориальных столбцов: {len(categorical_columns)}")

        for col in categorical_columns:
            self.update_output(f"\n{'-' * 70}")
            self.update_output(f"СТОЛБЕЦ: {col}")
            self.update_output(f"{'-' * 70}")

            unique_values = self.df[col].unique()
            unique_count = self.df[col].nunique()
            missing_count = self.df[col].isnull().sum()

            self.update_output(f"Количество уникальных значений: {unique_count}")
            self.update_output(f"Пропущенных значений: {missing_count}")

            if unique_count <= 20:  # Показываем все значения если их немного
                self.update_output(f"Уникальные значения: {list(unique_values)}")
            else:
                self.update_output(f"Первые 20 уникальных значений: {list(unique_values[:20])}")
                self.update_output(f"... и еще {unique_count - 20} значений")

            # Частотный анализ для топ-10 значений
            if unique_count > 0:
                self.update_output(f"\nТоп-10 самых частых значений:")
                value_counts = self.df[col].value_counts().head(10)
                for value, count in value_counts.items():
                    percentage = (count / len(self.df)) * 100
                    self.update_output(f"  {value}: {count} ({percentage:.2f}%)")

        # Специальный анализ для Booking Status и Vehicle Type
        self.update_output(f"\n{'-' * 70}")
        self.update_output("СПЕЦИАЛЬНЫЙ АНАЛИЗ ДЛЯ Booking Status И Vehicle Type")
        self.update_output(f"{'-' * 70}")

        # Поиск столбцов с booking status
        status_columns = [col for col in self.df.columns if 'status' in col.lower()]
        if status_columns:
            status_col = status_columns[0]
            self.analyze_specific_column(status_col, "Booking Status")
        else:
            self.update_output("Столбец Booking Status не найден")

        # Поиск столбцов с vehicle type
        vehicle_columns = [col for col in self.df.columns if 'vehicle' in col.lower()]
        if vehicle_columns:
            vehicle_col = vehicle_columns[0]
            self.analyze_specific_column(vehicle_col, "Vehicle Type")
        else:
            self.update_output("Столбец Vehicle Type не найден")

    def analyze_specific_column(self, column_name, display_name):
        """Анализ конкретного столбца"""
        self.update_output(f"\n{display_name} ({column_name}):")
        self.update_output(f"Уникальные значения: {list(self.df[column_name].unique())}")

        value_counts = self.df[column_name].value_counts()
        self.update_output(f"Распределение значений:")
        for value, count in value_counts.items():
            percentage = (count / len(self.df)) * 100
            self.update_output(f"  {value}: {count} ({percentage:.2f}%)")

    def show_overview(self):
        if self.df is None:
            messagebox.showwarning("Предупреждение", "Сначала загрузите данные")
            return

        self.clear_output()
        self.update_output("=" * 50)
        self.update_output("1. ОБЗОР ДАННЫХ")
        self.update_output("=" * 50)

        self.update_output(f"\nРеальные названия столбцов ({len(self.df.columns)}):")
        for i, col in enumerate(self.df.columns, 1):
            self.update_output(f"  {i}. {col}")

        self.update_output("\nПервые 5 строк:")
        self.update_output(str(self.df.head()))

        self.update_output("\nПропущенные значения:")
        missing = self.df.isnull().sum()
        has_missing = False
        for col, count in missing.items():
            if count > 0:
                self.update_output(f"  {col}: {count} пропусков")
                has_missing = True
        if not has_missing:
            self.update_output("  Пропущенных значений нет")

        self.update_output("\nСтатистика числовых столбцов:")
        self.update_output(str(self.df.describe()))

    def show_filters(self):
        if self.df is None:
            messagebox.showwarning("Предупреждение", "Сначала загрузите данные")
            return

        self.clear_output()
        self.update_output("=" * 50)
        self.update_output("2. ФИЛЬТРАЦИЯ ДАННЫХ")
        self.update_output("=" * 50)

        # Базовые фильтры из оригинального скрипта
        self.update_output("\nВыборка нескольких столбцов:")
        available_cols = self.df.columns[:3].tolist()
        self.update_output(f"Используем столбцы: {available_cols}")
        subset = self.df[available_cols].head(10)
        self.update_output(str(subset))

        # Фильтрация по статусу
        self.update_output("\nФильтрация по статусу:")
        status_columns = [col for col in self.df.columns if 'status' in col.lower() or 'Status' in col]
        if status_columns:
            status_col = status_columns[0]
            self.update_output(f"Найден столбец статусов: {status_col}")
            unique_statuses = self.df[status_col].unique()
            self.update_output(f"Уникальные статусы: {list(unique_statuses)}")

            cancel_statuses = [s for s in unique_statuses if 'cancel' in str(s).lower()]
            if cancel_statuses:
                cancel_status = cancel_statuses[0]
                cancelled = self.df[self.df[status_col] == cancel_status]
                self.update_output(f"Найдено отмененных бронирований: {len(cancelled)}")
                if len(cancelled) > 0:
                    self.update_output(str(cancelled[available_cols].head(10)))
        else:
            self.update_output("Столбец со статусами не найден")

        # Фильтрация по типу транспорта
        self.update_output("\nФильтрация по типу транспорта:")
        vehicle_columns = [col for col in self.df.columns if 'vehicle' in col.lower() or 'Vehicle' in col]
        if vehicle_columns:
            vehicle_col = vehicle_columns[0]
            self.update_output(f"Найден столбец транспорта: {vehicle_col}")
            unique_vehicles = self.df[vehicle_col].unique()
            self.update_output(f"Типы транспорта: {list(unique_vehicles)}")

            if len(unique_vehicles) > 0:
                first_vehicle = unique_vehicles[0]
                vehicle_data = self.df[self.df[vehicle_col] == first_vehicle]
                self.update_output(f"Найдено {first_vehicle}: {len(vehicle_data)}")
                if len(vehicle_data) > 0:
                    self.update_output(str(vehicle_data[available_cols].head(10)))
        else:
            self.update_output("Столбец с типом транспорта не найден")

    def full_analysis(self):
        if self.df is None:
            messagebox.showwarning("Предупреждение", "Сначала загрузите данные")
            return

        self.clear_output()

        # Обзор данных
        self.show_overview()

        # Фильтрация данных
        self.update_output("\n" + "=" * 50)
        self.show_filters()

        # Анализ пропущенных значений
        self.update_output("\n" + "=" * 50)
        self.analyze_missing_values()

        # Анализ уникальных значений
        self.update_output("\n" + "=" * 50)
        self.analyze_unique_values()

        self.update_output("\n" + "=" * 50)
        self.update_output("Анализ завершен!")
        self.update_status("Анализ завершен")

    def clear_output(self):
        self.output_area.delete(1.0, tk.END)

    def update_output(self, text):
        self.output_area.insert(tk.END, text + "\n")
        self.output_area.see(tk.END)
        self.root.update_idletasks()

    def update_status(self, text):
        self.status_var.set(text)
        self.root.update_idletasks()


def main():
    root = tk.Tk()
    app = UberAnalyzerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()