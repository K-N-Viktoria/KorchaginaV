import pandas as pd
import numpy as np

print("Анализ данных Uber")
print("=" * 50)

try:
    df = pd.read_csv("ncr_ride_bookings.csv")
    print("Файл загружен успешно!")
    print(f"Размер данных: {df.shape[0]} строк, {df.shape[1]} столбцов")
except FileNotFoundError:
    print("Файл 'ncr_ride_bookings.csv' не найден")
    exit()
except Exception as e:
    print(f"Ошибка при загрузке: {e}")
    exit()

print("\n" + "=" * 50)
print("1. ОБЗОР ДАННЫХ")
print("=" * 50)

print(f"\nРеальные названия столбцов ({len(df.columns)}):")
for i, col in enumerate(df.columns, 1):
    print(f"  {i}. {col}")

print("\nПервые 5 строк:")
print(df.head())

print("\nПропущенные значения:")
missing = df.isnull().sum()
for col, count in missing.items():
    if count > 0:
        print(f"  {col}: {count} пропусков")

print("\nСтатистика числовых столбцов:")
print(df.describe())

print("\n" + "=" * 50)
print("2. ФИЛЬТРАЦИЯ ДАННЫХ")
print("=" * 50)

print("\nВыборка нескольких столбцов:")
available_cols = df.columns[:3].tolist()
print(f"Используем столбцы: {available_cols}")
subset = df[available_cols].head(10)
print(subset)

print("\nФильтрация по статусу:")
status_columns = [col for col in df.columns if 'status' in col.lower() or 'Status' in col]
if status_columns:
    status_col = status_columns[0]
    print(f"Найден столбец статусов: {status_col}")
    unique_statuses = df[status_col].unique()
    print(f"Уникальные статусы: {list(unique_statuses)}")

    cancel_statuses = [s for s in unique_statuses if 'cancel' in str(s).lower()]
    if cancel_statuses:
        cancel_status = cancel_statuses[0]
        cancelled = df[df[status_col] == cancel_status]
        print(f"Найдено отмененных бронирований: {len(cancelled)}")
        if len(cancelled) > 0:
            print(cancelled[available_cols].head(10))
else:
    print("Столбец со статусами не найден")

print("\nФильтрация по типу транспорта:")
vehicle_columns = [col for col in df.columns if 'vehicle' in col.lower() or 'Vehicle' in col]
if vehicle_columns:
    vehicle_col = vehicle_columns[0]
    print(f"Найден столбец транспорта: {vehicle_col}")
    unique_vehicles = df[vehicle_col].unique()
    print(f"Типы транспорта: {list(unique_vehicles)}")

    if len(unique_vehicles) > 0:
        first_vehicle = unique_vehicles[0]
        vehicle_data = df[df[vehicle_col] == first_vehicle]
        print(f"Найдено {first_vehicle}: {len(vehicle_data)}")
        if len(vehicle_data) > 0:
            print(vehicle_data[available_cols].head(10))
else:
    print("Столбец с типом транспорта не найден")

print("\nПоиск столбцов с датами:")
date_columns = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()]
if date_columns:
    date_col = date_columns[0]
    print(f"Найден столбец с датой: {date_col}")
    print(f"Первые 5 дат: {df[date_col].head().tolist()}")
else:
    print("Столбцы с датами не найдены")

print("\n" + "=" * 50)
print("Анализ завершен!")