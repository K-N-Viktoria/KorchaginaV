import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

matplotlib.use('TkAgg')


class UberPricePredictor:
    def __init__(self):
        self.df = None
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_importance = None
        self.feature_names = None

    def load_data(self, file_path):
        """Загрузка и подготовка данных"""
        try:
            self.df = pd.read_csv(file_path)
            initial_count = len(self.df)
            self.df = self.df.dropna(subset=['Booking Value'])
            cleaned_count = len(self.df)

            if initial_count != cleaned_count:
                print(f"Удалено {initial_count - cleaned_count} записей с NaN в Booking Value")
            return self.df
        except Exception as e:
            raise Exception(f"Ошибка загрузки файла {file_path}: {str(e)}")

    def create_additional_features(self):
        """Создание дополнительных факторов"""
        try:
            # Временные факторы
            if 'Date' in self.df.columns and 'Time' in self.df.columns:
                self.df['booking_datetime'] = pd.to_datetime(self.df['Date'] + ' ' + self.df['Time'], errors='coerce')
                self.df = self.df.dropna(subset=['booking_datetime'])
                self.df['hour'] = self.df['booking_datetime'].dt.hour
                self.df['day_of_week'] = self.df['booking_datetime'].dt.dayofweek
                self.df['is_weekend'] = self.df['day_of_week'].isin([5, 6]).astype(int)
                self.df['month'] = self.df['booking_datetime'].dt.month
                self.df['is_peak_hours'] = ((self.df['hour'] >= 7) & (self.df['hour'] <= 9) |
                                            (self.df['hour'] >= 17) & (self.df['hour'] <= 19)).astype(int)
            else:
                np.random.seed(42)
                self.df['hour'] = np.random.randint(0, 24, len(self.df))
                self.df['day_of_week'] = np.random.randint(0, 7, len(self.df))
                self.df['is_weekend'] = (self.df['day_of_week'] >= 5).astype(int)
                self.df['month'] = np.random.randint(1, 13, len(self.df))
                self.df['is_peak_hours'] = ((self.df['hour'] >= 7) & (self.df['hour'] <= 9) |
                                            (self.df['hour'] >= 17) & (self.df['hour'] <= 19)).astype(int)

            # Дополнительные факторы
            np.random.seed(42)
            self.df['temperature'] = np.random.normal(25, 8, len(self.df))
            self.df['precipitation'] = np.random.exponential(0.5, len(self.df))
            self.df['is_rainy'] = (self.df['precipitation'] > 1).astype(int)
            self.df['demand_surge'] = np.random.lognormal(0, 0.3, len(self.df))
            self.df['driver_availability'] = np.random.beta(2, 5, len(self.df))
            self.df['trip_distance_km'] = np.random.gamma(5, 2, len(self.df))
            self.df['estimated_duration_min'] = self.df['trip_distance_km'] * 3 + np.random.normal(0, 5, len(self.df))
            self.df['is_city_center'] = np.random.choice([0, 1], len(self.df), p=[0.7, 0.3])
            self.df['area_traffic_density'] = np.random.beta(2, 3, len(self.df))
            self.df['user_rating'] = np.random.normal(4.5, 0.5, len(self.df)).clip(1, 5)
            self.df['user_experience_level'] = np.random.choice(['new', 'regular', 'veteran'], len(self.df),
                                                                p=[0.2, 0.5, 0.3])
            self.df['fuel_price_index'] = np.random.normal(1.0, 0.1, len(self.df))
            self.df['daylight_hours'] = 12 + 4 * np.sin(2 * np.pi * (self.df['month'] - 3) / 12)
            self.df['is_holiday'] = np.random.choice([0, 1], len(self.df), p=[0.9, 0.1])
            self.df['special_event_multiplier'] = 1 + 0.5 * self.df['is_holiday']

        except Exception as e:
            raise Exception(f"Ошибка создания дополнительных признаков: {str(e)}")

    def prepare_features_for_ml(self):
        """Подготовка признаков для машинного обучения"""
        try:
            y = self.df['Booking Value'].copy()
            if y.isnull().any():
                y = y.fillna(y.median())

            feature_columns = [
                'hour', 'day_of_week', 'is_weekend', 'month', 'is_peak_hours',
                'temperature', 'precipitation', 'is_rainy', 'demand_surge',
                'driver_availability', 'trip_distance_km', 'estimated_duration_min',
                'is_city_center', 'area_traffic_density', 'user_rating',
                'fuel_price_index', 'daylight_hours', 'is_holiday'
            ]

            X = self.df[feature_columns].copy()

            for col in X.columns:
                if X[col].isnull().any():
                    if X[col].dtype in ['float64', 'int64']:
                        X[col] = X[col].fillna(X[col].median())
                    else:
                        X[col] = X[col].fillna(X[col].mode()[0] if not X[col].mode().empty else 0)

            if 'user_experience_level' in self.df.columns:
                self.label_encoders['user_experience_level'] = LabelEncoder()
                self.df['user_experience_level'] = self.df['user_experience_level'].fillna('unknown')
                X['user_experience_level'] = self.label_encoders['user_experience_level'].fit_transform(
                    self.df['user_experience_level'])

            if 'Vehicle Type' in self.df.columns:
                self.label_encoders['Vehicle Type'] = LabelEncoder()
                self.df['Vehicle Type'] = self.df['Vehicle Type'].fillna('Unknown')
                X['vehicle_type_encoded'] = self.label_encoders['Vehicle Type'].fit_transform(self.df['Vehicle Type'])

            if X.isnull().any().any() or y.isnull().any():
                mask = ~X.isnull().any(axis=1) & ~y.isnull()
                X = X[mask]
                y = y[mask]

            self.feature_names = X.columns.tolist()
            return X, y

        except Exception as e:
            raise Exception(f"Ошибка подготовки данных для ML: {str(e)}")

    def train_model(self):
        """Обучение модели машинного обучения"""
        try:
            X, y = self.prepare_features_for_ml()

            if len(X) == 0 or len(y) == 0:
                raise ValueError("Нет данных для обучения после очистки!")

            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            self.feature_names = X_train.columns.tolist()

            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)

            self.model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            )
            self.model.fit(X_train_scaled, y_train)

            y_pred = self.model.predict(X_test_scaled)
            mae = mean_absolute_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

            self.feature_importance = pd.DataFrame({
                'feature': self.feature_names,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)

            return mae, r2

        except Exception as e:
            raise Exception(f"Ошибка обучения модели: {str(e)}")

    def predict_price(self, input_features):
        """Предсказание стоимости для новых данных"""
        if self.model is None:
            raise ValueError("Модель не обучена! Сначала обучите модель.")

        try:
            input_df = pd.DataFrame([input_features])

            for feature in self.feature_names:
                if feature not in input_df.columns:
                    input_df[feature] = 0

            input_df = input_df[self.feature_names]
            input_scaled = self.scaler.transform(input_df)
            return self.model.predict(input_scaled)[0]

        except Exception as e:
            raise Exception(f"Ошибка предсказания: {str(e)}")


class ModernUberPredictorGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🚗 Uber Price Predictor Pro")
        self.root.geometry("1400x900")
        self.root.configure(bg='#2c3e50')

        self.predictor = UberPricePredictor()
        self.setup_ui()

    def setup_ui(self):
        """Создание интерфейса как в изначальном рабочем варианте"""
        # Главный контейнер
        main_frame = tk.Frame(self.root, bg='#2c3e50')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Заголовок
        header_frame = tk.Frame(main_frame, bg='#34495e', height=100)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        header_frame.pack_propagate(False)

        title_label = tk.Label(header_frame,
                               text="🚗 UBER PRICE PREDICTOR PRO",
                               font=('Arial', 24, 'bold'),
                               bg='#34495e',
                               fg='#3498db')
        title_label.pack(pady=20)

        subtitle_label = tk.Label(header_frame,
                                  text="AI-powered ride cost estimation",
                                  font=('Arial', 12),
                                  bg='#34495e',
                                  fg='#bdc3c7')
        subtitle_label.pack()

        # Основной контент
        content_frame = tk.Frame(main_frame, bg='#2c3e50')
        content_frame.pack(fill=tk.BOTH, expand=True)

        # Левая панель - управление
        left_panel = tk.Frame(content_frame, bg='#2c3e50', width=400)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 20))
        left_panel.pack_propagate(False)

        # Правая панель - информация
        right_panel = tk.Frame(content_frame, bg='#2c3e50')
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Настройка левой панели
        self.setup_left_panel(left_panel)

        # Настройка правой панели
        self.setup_right_panel(right_panel)

        # Статус бар
        self.setup_status_bar(main_frame)

    def setup_left_panel(self, parent):
        """Настройка левой панели с кнопками и калькулятором"""

        # Панель управления
        control_frame = tk.Frame(parent, bg='#34495e', bd=1, relief='raised', padx=20, pady=20)
        control_frame.pack(fill=tk.X, pady=(0, 20))

        control_label = tk.Label(control_frame, text="Управление системой",
                                 font=('Arial', 14, 'bold'),
                                 bg='#34495e', fg='white')
        control_label.pack(anchor='w', pady=(0, 15))

        # Кнопки управления
        self.load_btn = tk.Button(control_frame,
                                  text="📁 ЗАГРУЗИТЬ ДАННЫЕ",
                                  font=('Arial', 11, 'bold'),
                                  bg='#3498db', fg='white', bd=0,
                                  padx=20, pady=12,
                                  command=self.load_data)
        self.load_btn.pack(fill=tk.X, pady=8)

        self.train_btn = tk.Button(control_frame,
                                   text="🤖 ОБУЧИТЬ МОДЕЛЬ",
                                   font=('Arial', 11, 'bold'),
                                   bg='#9b59b6', fg='white', bd=0,
                                   padx=20, pady=12,
                                   command=self.train_model,
                                   state=tk.DISABLED)
        self.train_btn.pack(fill=tk.X, pady=8)

        # Калькулятор
        calc_frame = tk.Frame(parent, bg='#34495e', bd=1, relief='raised', padx=20, pady=20)
        calc_frame.pack(fill=tk.BOTH, expand=True)

        calc_label = tk.Label(calc_frame, text="Калькулятор поездки",
                              font=('Arial', 14, 'bold'),
                              bg='#34495e', fg='white')
        calc_label.pack(anchor='w', pady=(0, 15))

        # Поля ввода
        input_frame = tk.Frame(calc_frame, bg='#34495e')
        input_frame.pack(fill=tk.BOTH, expand=True)

        # Левая колонка
        left_col = tk.Frame(input_frame, bg='#34495e')
        left_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        # Правая колонка
        right_col = tk.Frame(input_frame, bg='#34495e')
        right_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))

        self.entry_vars = {}

        # Поля слева
        left_fields = [
            ("Час поездки (0-23):", "hour"),
            ("Температура (°C):", "temperature"),
            ("Дистанция (км):", "trip_distance_km"),
            ("Плотность трафика (0-1):", "area_traffic_density")
        ]

        for label, var_name in left_fields:
            self.create_simple_input(left_col, label, var_name)

        # Поля справа
        right_fields = [
            ("День недели (0-6):", "day_of_week"),
            ("Осадки (мм):", "precipitation"),
            ("Длительность (мин):", "estimated_duration_min"),
            ("Уровень спроса (1-3):", "demand_surge")
        ]

        for label, var_name in right_fields:
            self.create_simple_input(right_col, label, var_name)

        # Чекбоксы
        checks_frame = tk.Frame(calc_frame, bg='#34495e')
        checks_frame.pack(fill=tk.X, pady=15)

        self.is_weekend_var = tk.BooleanVar()
        tk.Checkbutton(checks_frame, text="Выходной день", variable=self.is_weekend_var,
                       bg='#34495e', fg='white', selectcolor='#2c3e50').pack(side=tk.LEFT, padx=(0, 20))

        self.is_peak_var = tk.BooleanVar()
        tk.Checkbutton(checks_frame, text="Пиковые часы", variable=self.is_peak_var,
                       bg='#34495e', fg='white', selectcolor='#2c3e50').pack(side=tk.LEFT, padx=(0, 20))

        self.is_rainy_var = tk.BooleanVar()
        tk.Checkbutton(checks_frame, text="Дождливая погода", variable=self.is_rainy_var,
                       bg='#34495e', fg='white', selectcolor='#2c3e50').pack(side=tk.LEFT, padx=(0, 20))

        # ДОБАВЛЕН ЧЕКБОКС ДЛЯ ЦЕНТРА ГОРОДА
        self.is_city_center_var = tk.BooleanVar()
        tk.Checkbutton(checks_frame, text="Центр города", variable=self.is_city_center_var,
                       bg='#34495e', fg='white', selectcolor='#2c3e50').pack(side=tk.LEFT)

        # КНОПКА РАССЧИТАТЬ СТОИМОСТЬ
        self.calc_btn = tk.Button(calc_frame,
                                  text="🚀 РАССЧИТАТЬ СТОИМОСТЬ",
                                  font=('Arial', 12, 'bold'),
                                  bg='#e74c3c', fg='white', bd=0,
                                  padx=30, pady=15,
                                  command=self.calculate_ride,
                                  state=tk.DISABLED)
        self.calc_btn.pack(fill=tk.X, pady=15)

        # Результат
        self.result_var = tk.StringVar(value="💡 Введите параметры поездки")
        result_label = tk.Label(calc_frame, textvariable=self.result_var,
                                font=('Arial', 16, 'bold'),
                                bg='#34495e',
                                fg='#f39c12',
                                pady=10)
        result_label.pack(fill=tk.X)

    def create_simple_input(self, parent, label, var_name):
        """Создание простого поля ввода"""
        frame = tk.Frame(parent, bg='#34495e')
        frame.pack(fill=tk.X, pady=5)

        tk.Label(frame, text=label, bg='#34495e', fg='white', font=('Arial', 9)).pack(anchor='w')

        var = tk.StringVar(value="0")
        tk.Entry(frame, textvariable=var, bg='#2c3e50', fg='white',
                 insertbackground='white', bd=1, relief='sunken').pack(fill=tk.X, pady=2)

        self.entry_vars[var_name] = var

    def setup_right_panel(self, parent):
        """Настройка правой панели"""
        # Вкладки
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True)

        # Вкладка логов
        log_frame = tk.Frame(notebook, bg='#34495e')
        notebook.add(log_frame, text='📊 Логи')

        self.text_area = scrolledtext.ScrolledText(log_frame,
                                                   wrap=tk.WORD,
                                                   font=('Consolas', 9),
                                                   bg='#1a1a1a',
                                                   fg='#00ff00',
                                                   padx=10,
                                                   pady=10)
        self.text_area.pack(fill=tk.BOTH, expand=True)

        # Вкладка статистики
        stats_frame = tk.Frame(notebook, bg='#34495e')
        notebook.add(stats_frame, text='📈 Статистика')

        # Вкладка графиков
        graph_frame = tk.Frame(notebook, bg='#34495e')
        notebook.add(graph_frame, text='📉 Графики')

        # Настройка графика
        self.fig = Figure(figsize=(10, 8), facecolor='#34495e')
        self.ax = self.fig.add_subplot(111, facecolor='#34495e')

        self.ax.text(0.5, 0.5, '📊 График будет отображен после обучения модели',
                     horizontalalignment='center', verticalalignment='center',
                     transform=self.ax.transAxes, fontsize=14,
                     color='#bdc3c7')
        self.ax.set_xticks([])
        self.ax.set_yticks([])

        self.canvas = FigureCanvasTkAgg(self.fig, graph_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def setup_status_bar(self, parent):
        """Настройка статус бара"""
        status_frame = tk.Frame(parent, bg='#34495e', height=30)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=(10, 0))
        status_frame.pack_propagate(False)

        self.status_var = tk.StringVar(value="🟢 Готов к работе. Загрузите данные для начала.")
        status_label = tk.Label(status_frame,
                                textvariable=self.status_var,
                                font=('Arial', 9),
                                bg='#34495e',
                                fg='#ecf0f1')
        status_label.pack(side=tk.LEFT, padx=15)

    def log_message(self, message):
        """Логирование сообщений"""
        self.text_area.insert(tk.END, f"{datetime.now().strftime('%H:%M:%S')} - {message}\n")
        self.text_area.see(tk.END)
        self.root.update()

    def clear_logs(self):
        """Очистка логов"""
        self.text_area.delete(1.0, tk.END)

    def load_data(self):
        """Загрузка данных"""
        try:
            self.status_var.set("🔄 Загрузка данных...")
            self.load_btn.config(state=tk.DISABLED)

            try:
                df = self.predictor.load_data('ncr_ride_bookings.csv')
            except FileNotFoundError:
                self.create_demo_data()
                df = self.predictor.load_data('ncr_ride_bookings.csv')

            self.predictor.create_additional_features()

            self.status_var.set(f"✅ Данные загружены: {len(df)} записей")
            self.train_btn.config(state=tk.NORMAL)

            self.clear_logs()
            self.log_message("🎯 ДАННЫЕ УСПЕШНО ЗАГРУЖЕНЫ")
            self.log_message(f"📊 Записей: {df.shape[0]:,}")
            self.log_message(f"💰 Средняя стоимость: {df['Booking Value'].mean():.2f} руб.")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить данные:\n{str(e)}")
            self.status_var.set("❌ Ошибка загрузки данных")
        finally:
            self.load_btn.config(state=tk.NORMAL)

    def create_demo_data(self):
        """Создание демо-данных"""
        np.random.seed(42)
        n_records = 1000

        demo_data = {
            'Date': pd.date_range('2024-01-01', periods=n_records).strftime('%Y-%m-%d'),
            'Time': [f"{np.random.randint(0, 24):02d}:{np.random.randint(0, 60):02d}" for _ in range(n_records)],
            'Booking Value': np.random.gamma(2, 100, n_records) + 100,
            'Vehicle Type': np.random.choice(['Auto', 'Mini', 'Prime Sedan', 'SUV'], n_records)
        }

        df = pd.DataFrame(demo_data)
        df.to_csv('ncr_ride_bookings.csv', index=False)
        self.log_message("📁 Создан демо-файл с данными")

    def train_model(self):
        """Обучение модели"""
        try:
            self.status_var.set("🔄 Обучение модели...")
            self.train_btn.config(state=tk.DISABLED)

            mae, r2 = self.predictor.train_model()

            accuracy = max(0, r2 * 100)
            self.status_var.set(f"✅ Модель обучена | MAE: {mae:.2f} | Точность: {accuracy:.1f}%")
            self.calc_btn.config(state=tk.NORMAL)

            self.log_message("🤖 МОДЕЛЬ УСПЕШНО ОБУЧЕНА")
            self.log_message(f"🎯 Точность: {accuracy:.1f}%")

            # Обновляем график
            self.update_visualization()

        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка обучения модели:\n{str(e)}")
            self.status_var.set("❌ Ошибка обучения")

    def update_visualization(self):
        """Обновление визуализации"""
        if self.predictor.feature_importance is not None:
            self.ax.clear()

            features = self.predictor.feature_importance.head(8)
            colors = plt.cm.Set3(np.linspace(0, 1, len(features)))
            bars = self.ax.barh(features['feature'], features['importance'], color=colors)

            self.ax.set_xlabel('Важность признака', color='white', fontsize=12)
            self.ax.set_title('ТОП-8 ВАЖНЫХ ФАКТОРОВ', color='white', fontsize=14)

            for i, (bar, importance) in enumerate(zip(bars, features['importance'])):
                self.ax.text(importance + 0.01, bar.get_y() + bar.get_height() / 2,
                             f'{importance:.3f}', ha='left', va='center',
                             color='white', fontsize=10)

            self.ax.tick_params(colors='white', labelsize=10)
            for spine in self.ax.spines.values():
                spine.set_color('white')
            self.ax.grid(True, alpha=0.3, color='white')

            self.fig.tight_layout()
            self.canvas.draw()

    def calculate_ride(self):
        """Расчет стоимости поездки"""
        try:
            # Сбор данных из формы
            input_features = {
                'hour': float(self.entry_vars['hour'].get()),
                'day_of_week': float(self.entry_vars['day_of_week'].get()),
                'is_weekend': 1 if self.is_weekend_var.get() else 0,
                'month': 6,
                'is_peak_hours': 1 if self.is_peak_var.get() else 0,
                'temperature': float(self.entry_vars['temperature'].get()),
                'precipitation': float(self.entry_vars['precipitation'].get()),
                'is_rainy': 1 if self.is_rainy_var.get() else 0,
                'demand_surge': float(self.entry_vars['demand_surge'].get()),
                'driver_availability': 0.5,
                'trip_distance_km': float(self.entry_vars['trip_distance_km'].get()),
                'estimated_duration_min': float(self.entry_vars['estimated_duration_min'].get()),
                'is_city_center': 1 if self.is_city_center_var.get() else 0,
                'area_traffic_density': float(self.entry_vars['area_traffic_density'].get()),
                'user_rating': 4.5,
                'fuel_price_index': 1.0,
                'daylight_hours': 12,
                'is_holiday': 0,
                'user_experience_level': 1,
                'vehicle_type_encoded': 0
            }

            predicted_price = self.predictor.predict_price(input_features)

            # Форматируем результат
            result_text = f"💰 {predicted_price:.0f} РУБ."
            self.result_var.set(result_text)

            # Логируем расчет
            self.log_message(f"🧮 РАСЧЕТНАЯ СТОИМОСТЬ: {predicted_price:.0f} руб.")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка расчета:\n{str(e)}")
            self.result_var.set("❌ Ошибка расчета")

    def run(self):
        """Запуск приложения"""
        self.root.mainloop()


# Запуск приложения
if __name__ == "__main__":
    try:
        print("🚗 Запуск Uber Price Predictor Pro...")
        app = ModernUberPredictorGUI()
        app.run()
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()